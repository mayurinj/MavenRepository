package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotel;
import com.cg.hbms.dto.Users;
import com.cg.hbms.dto.roomDetails;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.util.DBUtil;

public class AdminDaoImpl implements AdminDao {
	Connection con;

	public AdminDaoImpl() throws HotelException {
		con = DBUtil.getcon();

	}

	@Override
	public ArrayList<Hotel> getAllHotels() throws HotelException {
		// TODO Auto-generated method stub
		String qry = "SELECT * FROM Hotel";
		ArrayList<Hotel> list = new ArrayList<Hotel>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while (rs.next()) {
				Hotel hotel = new Hotel(rs.getString("hotel_id"), rs.getString("city"), rs.getString("hotel_name"),
						rs.getString("address"), rs.getString("description"), rs.getInt("avg_rate_per_night"),
						rs.getString("phone_no1"), rs.getString("phone_no2"), rs.getString("rating"),
						rs.getString("email"), rs.getString("fax"));
				list.add(hotel);
			}
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return list;
	}

	@Override
	public int deleteHotel(int hotel_id) throws HotelException {
		// TODO Auto-generated method stub
		int delrec = 0;
		try {
			PreparedStatement pst = con.prepareStatement("DELETE from Hotel WHERE hotel_id=?");
			String id = Integer.toString(hotel_id);
			pst.setString(1, id);
			pst.executeUpdate();
			delrec = 1;
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return delrec;
	}

	@Override
	public int updateHotel(Hotel hotel) throws HotelException {
		int i = 0;
		try {
			String qry = "update Hotel set city=?,hotel_name=?,address=?,description=?,avg_rate_per_night=?,phone_no1=?,phone_no2=?,rating=?,email=?,fax=?  WHERE hotel_id=?";

			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, hotel.getCity());
			pstmt.setString(2, hotel.getHotel_name());
			pstmt.setString(3, hotel.getAddress());
			pstmt.setString(4, hotel.getDescription());
			pstmt.setInt(5, hotel.getAvg_rate_per_night());
			pstmt.setString(6, hotel.getPhone_no1());
			pstmt.setString(7, hotel.getPhone_no2());
			pstmt.setString(8, hotel.getRating());
			pstmt.setString(9, hotel.getEmail());
			pstmt.setString(10, hotel.getFax());
			pstmt.setString(11, hotel.getHotel_id());
			i = pstmt.executeUpdate();
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return i;

	}

	@Override
	public ArrayList<BookingDetails> getAllBookingsByHotel(String hotel_id) throws HotelException {
		// TODO Auto-generated method stub
		ArrayList<BookingDetails> list = null;
		try {
			String qry = "select r.hotel_id,b.booking_id,r.room_id,b.user_id,b.booked_from,b.booked_to,b.no_of_adults,b.no_of_children,b.amount from bookingdetails b,roomdetails r,hotel h where  b.room_id = r.room_id and r.hotel_id = ?";
			PreparedStatement pst1 = con.prepareStatement(qry);
			pst1.setString(1, hotel_id);
			ResultSet rs = pst1.executeQuery();
			list = new ArrayList<BookingDetails>();

			while (rs.next()) {
				BookingDetails book = new BookingDetails(rs.getString("hotel_id"), rs.getString("booking_id"),
						rs.getString("room_id"), rs.getString("user_id"),
						MyStringDateUtil.fromSqlToLocalDate(rs.getDate("booked_from")),
						MyStringDateUtil.fromSqlToLocalDate(rs.getDate("booked_to")), rs.getInt("no_of_adults"),
						rs.getInt("no_of_children"), rs.getInt("amount"));
				list.add(book);

			}
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return list;
	}

	@Override
	public ArrayList<BookingDetails> viewBookingForSpecificDate(LocalDate date) throws HotelException {
		ArrayList<BookingDetails> list = null;
		try {
			Date date1 = MyStringDateUtil.fromLocalToSqlDate(date);
			String qry = "SELECT * from bookingdetails where booked_from=?";
			PreparedStatement pst1 = con.prepareStatement(qry);
			pst1.setDate(1, date1);
			ResultSet rs = pst1.executeQuery();
			list = new ArrayList<BookingDetails>();
			while (rs.next()) {
				BookingDetails book = new BookingDetails(rs.getString("booking_id"), rs.getString("room_id"),
						rs.getString("user_id"), MyStringDateUtil.fromSqlToLocalDate(rs.getDate("booked_from")),
						MyStringDateUtil.fromSqlToLocalDate(rs.getDate("booked_to")), rs.getInt("no_of_adults"),
						rs.getInt("no_of_children"), rs.getInt("amount"));
				list.add(book);
			}
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return list;
	}

	@Override
	public int addRoomDetails(roomDetails room) throws HotelException {
		int insRoom = 0;
		try {
			String qry = "INSERT INTO RoomDetails VALUES(?,?,?,?,?,?)";
			PreparedStatement pst1 = con.prepareStatement(qry);
			pst1.setString(1, room.getHotel_id());
			pst1.setString(2, room.getRoom_id());
			pst1.setString(3, room.getRoom_no());
			pst1.setString(4, room.getRoom_type());
			pst1.setDouble(5, room.getPer_night_rate());
			pst1.setString(6, String.valueOf(room.isAvailability()));
			insRoom = pst1.executeUpdate();
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return insRoom;
	}

	@Override
	public int deleteRoom(String roomId) throws HotelException {
		int delRoom = 0;
		try {
			String qry = "DELETE FROM RoomDetails WHERE room_id=?";
			PreparedStatement pst1 = con.prepareStatement(qry);
			pst1.setString(1, roomId);
			delRoom = pst1.executeUpdate();
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return delRoom;
	}

	@Override
	public roomDetails getRoomByRoomId(String roomId) throws HotelException {
		roomDetails room = null;
		try {
			String qry = "SELECT * FROM RoomDetails WHERE room_id=?";
			PreparedStatement pst1 = con.prepareStatement(qry);
			pst1.setString(1, roomId);
			ResultSet rs = pst1.executeQuery();
			while (rs.next()) {
				room = new roomDetails(rs.getString("hotel_id"), rs.getString("room_id"), rs.getString("room_no"),
						rs.getString("room_type"), rs.getDouble("per_night_rate"),
						rs.getString("availability").charAt(0));
			}
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return room;
	}

	@Override
	public int updateRoomDetails(roomDetails room) throws HotelException {
		int upRoom = 0;
		try {
			String qry = "UPDATE RoomDetails SET per_night_rate = ? where room_id=?";
			PreparedStatement pst1 = con.prepareStatement(qry);
			pst1.setDouble(1, room.getPer_night_rate());
			pst1.setString(2, room.getRoom_id());
			upRoom = pst1.executeUpdate();
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return upRoom;
	}

	@Override
	public Hotel getHotelByHotelId(String HotelId) throws HotelException {
		Hotel hotel = null;
		try {
			String qry = "Select * from Hotel Where hotel_id=?";
			PreparedStatement pst1 = con.prepareStatement(qry);
			pst1.setString(1, HotelId);
			ResultSet rs = pst1.executeQuery();
			while (rs.next()) {
				hotel = new Hotel(rs.getString("hotel_id"), rs.getString("city"), rs.getString("hotel_name"),
						rs.getString("address"), rs.getString("description"), rs.getInt("avg_rate_per_night"),
						rs.getString("phone_no1"), rs.getString("phone_no2"), rs.getString("rating"),
						rs.getString("email"), rs.getString("fax"));
			}
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return hotel;
	}

	@Override
	public void addHotel(Hotel hotel) throws HotelException {
		int dataIns = 0;
		try {
			con = DBUtil.getcon();
			System.out.println("con=" + con);// for checking the connection
			PreparedStatement pst1 = con.prepareStatement("INSERT into Hotel Values (?,?,?,?,?,?,?,?,?,?,?)");
			pst1.setString(1, hotel.getHotel_id());
			pst1.setString(2, hotel.getCity());
			pst1.setString(3, hotel.getHotel_name());
			pst1.setString(4, hotel.getAddress());
			pst1.setString(5, hotel.getDescription());
			pst1.setFloat(6, hotel.getAvg_rate_per_night());
			pst1.setString(7, hotel.getPhone_no1());
			pst1.setString(8, hotel.getPhone_no2());
			pst1.setString(9, hotel.getRating());
			pst1.setString(10, hotel.getEmail());
			pst1.setString(11, hotel.getFax());
			dataIns = pst1.executeUpdate();
			System.out.println(dataIns);
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public int addAdmin(Users user) throws HotelException {
		int i = 0;
		try	{
			String qry = "Insert into Users VALUES(?,?,?,?,?,?,?,?)";
			PreparedStatement pst1 = con.prepareStatement(qry);
			pst1.setString(1, user.getUser_id());
			pst1.setString(2, user.getPassword());
			pst1.setString(3, user.getRole());
			pst1.setString(4, user.getUser_name());
			pst1.setString(5, user.getMobile_phone());
			pst1.setString(6, user.getPhone());
			pst1.setString(7, user.getAddress());
			pst1.setString(8, user.getEmail());
			i = pst1.executeUpdate();
		}
		catch(Exception e)	{
			throw new HotelException(e.getMessage());
		}
		return i;
	}
}
