# HBMS

Hotel Booking Management System

1.  Created Using Layered Architecture
2.  Language Used- Java version 8
3.  Sql - Oracle Sql
4.  Software Used - Spring Tool Suite Version 3.9.6
5.  Operating System - Windows 7
6.  Hardware Used for the Project - 
    - intel Core i5
    - 8 GB ram
    - 512 GB Storage

# DeadLines

Complete By 10 Sept

